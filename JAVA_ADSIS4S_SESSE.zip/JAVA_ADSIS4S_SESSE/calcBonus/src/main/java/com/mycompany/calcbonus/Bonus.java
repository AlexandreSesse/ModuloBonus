/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.calcbonus;

/**
 *
 * @author alese
 */

import java.util.List;
class Bonus {

    public int calcularBonus(List<Funcionario> funcionarios, List<Departamento> departamentos) {
        if (funcionarios.isEmpty() || departamentos.isEmpty()) {
            return 1;
        }

        double maiorVenda = 0;
        for (Departamento dep : departamentos) {
            if (dep.getValorDeVendas() > maiorVenda) {
                maiorVenda = dep.getValorDeVendas();
            }
        }

        boolean funcionarioElegivel = false;
        for (Funcionario func : funcionarios) {
            if (func.getDepartamento().getValorDeVendas() == maiorVenda) {
                funcionarioElegivel = true;
                func.aplicarBonus();
            }
        }

        if (!funcionarioElegivel) {
            return 2;
        }

        return 0;
    }
}
