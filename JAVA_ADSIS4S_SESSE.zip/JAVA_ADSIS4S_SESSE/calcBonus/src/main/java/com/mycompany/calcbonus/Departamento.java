/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.calcbonus;

/**
 *
 * @author alese
 */
class Departamento {
    private int id;
    private double valorDeVendas;

    public Departamento(int id, double valorDeVendas) {
        this.id = id;
        this.valorDeVendas = valorDeVendas;
    }

    public int getId() {
        return id;
    }

    public double getValorDeVendas() {
        return valorDeVendas;
    }
}
