/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.calcbonus;

/**
 *
 * @author alese
 */
import java.util.List;

abstract class Funcionario {
    protected int id;
    protected double salario;
    protected String cargo;
    protected Departamento departamento;

    public Funcionario(int id, double salario, String cargo, Departamento departamento) {
        this.id = id;
        this.salario = salario;
        this.cargo = cargo;
        this.departamento = departamento;
    }

    public abstract void aplicarBonus();

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public boolean isGerente() {
        return "Gerente".equalsIgnoreCase(this.cargo);
    }
}