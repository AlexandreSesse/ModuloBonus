/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.calcbonus;

/**
 *
 * @author alese
 */
class Gerente extends Funcionario {

    public Gerente(int id, double salario, String cargo, Departamento departamento) {
        super(id, salario, cargo, departamento);
    }

    @Override
    public void aplicarBonus() {
        this.salario += 1000;
    }
}