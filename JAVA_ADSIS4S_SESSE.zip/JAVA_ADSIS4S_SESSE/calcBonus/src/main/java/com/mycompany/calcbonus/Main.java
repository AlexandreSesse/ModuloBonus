/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.calcbonus;

import java.util.List;

/**
 *
 * @author alese
 */

public class Main {
    public static void main(String[] args) {
        Departamento dep1 = new Departamento(1, 50000);
        Departamento dep2 = new Departamento(2, 150000);
        Departamento dep3 = new Departamento(3, 150000);

        Funcionario vendedor1 = new Vendedor(1, 120000, "Vendedor", dep1, 0.05, 20000);
        Funcionario gerente1 = new Gerente(2, 160000, "Gerente", dep2);
        Funcionario vendedor2 = new Vendedor(3, 130000, "Vendedor", dep3, 0.03, 30000);

        List<Funcionario> funcionarios = List.of(vendedor1, gerente1, vendedor2);
        List<Departamento> departamentos = List.of(dep1, dep2, dep3);

        Bonus bonusController = new Bonus();
        int resultado = bonusController.calcularBonus(funcionarios, departamentos);

        System.out.println("Resultado da execução: " + resultado);
        System.out.println("Salário atualizado vendedor1: " + vendedor1.getSalario());
        System.out.println("Salário atualizado gerente1: " + gerente1.getSalario());
        System.out.println("Salário atualizado vendedor2: " + vendedor2.getSalario());
    }
}
