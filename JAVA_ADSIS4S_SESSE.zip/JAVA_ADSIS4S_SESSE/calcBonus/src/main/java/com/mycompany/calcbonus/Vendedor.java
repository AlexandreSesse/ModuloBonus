/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.calcbonus;

/**
 *
 * @author alese
 */
class Vendedor extends Funcionario {
    private double comissao;
    private double vendas;

    public Vendedor(int id, double salario, String cargo, Departamento departamento, double comissao, double vendas) {
        super(id, salario, cargo, departamento);
        this.comissao = comissao;
        this.vendas = vendas;
    }

    @Override
    public void aplicarBonus() {
        if (this.salario >= 150000 || isGerente()) {
            this.salario += 1000;
        } else {
            this.salario += 2000;
        }
    }
}